#!/bin/bash
SUM=`expr $1 + $2`
echo "$1 + $2 = $SUM"
