#!/bin/bash
/etc/init.d/vsftpd status &> /dev/null
if [ $? -eq 0 ]
then
    echo "监听地址：$(netstat -anpt | grep vsftpd | awk '{print $4}')"
    echo "进程PID号：$(pgrep -x vsftpd)"
else
    echo "警告：vsftpd 服务不可用！"
fi
