#!/bin/bash
ULIST=$(cat /root/users.txt)
for UNAME in $ULIST
do
    useradd $UNAME
    echo "123456" | passwd --stdin $UNAME &> /dev/null
done
