#!/bin/bash
PREFIX="stu"
i=1
while [ $i -le 20 ]
do
    useradd ${PREFIX}$i
	echo "123456" | passwd --stdin ${PREFIX}$i &> /dev/null
	let i++
done
