#!/bin/bash
ULIST=$(cat /root/users.txt)
for UNAME in $ULIST
do
    userdel -r $UNAME
done
