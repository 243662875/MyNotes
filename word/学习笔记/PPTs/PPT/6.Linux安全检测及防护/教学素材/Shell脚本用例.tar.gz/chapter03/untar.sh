#!/bin/bash
case "$1" in
  *.tar.bz2)
      tar jxvf $1
      ;;
  *.tar.gz)
      tar zxvf $1
      ;;
  *)
    echo "不支持的文件格式."
esac

